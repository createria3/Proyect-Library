//EJEMPLO 10.13. Paso por referencia en C y en C++.
#include <cstdlib>
#include <iostream>
using namespace std;
struct datos
{
	float mayor, menor;
};
void leer_registrodatosCmasmas(datos &t) // par�metro por referecia en C++
{
	float actual;
	cin >> actual;
	if (actual > t.mayor)
		t.mayor = actual;
	else if (actual < t.menor)
		t.menor = actual;
}
void leer_registrodatosC(datos *t) // par�metro direcci�n C, referencia
{
	float dat;
	cin >> dat;
	if (dat > t -> mayor)
	t -> mayor = dat;
	else if (dat < t -> menor)
	t -> menor = dat;
}
int main(int argc, char *argv[])
{ datos dat;
//.....
	leer_registrodatosCmasmas(dat); // llamada por referencia en C++
	leer_registrodatosC(&dat); // llamada por direcci�n en C
	system("PAUSE");
	return EXIT_SUCCESS;
}
