/*EJEMPLO 19.2. Funci�n recursiva directa que cuenta, visualizando resultados y mostrando el fincionamiento de la pila interna.

El siguiente programa permite observar al funcionamiento de la recursividad. La funci�n contar decrementa el par�metro
y lo muestra y si el valor es mayor a cero, se llama a s� misma donde decrementa el par�metro una vez m�s
en caso de que sea positivo, y en caso de que no sea positivo no hace nada, que es la parada de la funci�n. Cuando el
par�metro alcanza el valor de cero La funci�n ya no se llam a s� misma y se producen sucesivos retornos al punto siguiente
a donde se efectuaron las llamadas, donde se recupera de la pila el valor del parametro y se muestra*/

#include<cstdlib>
#include<iostream>
using namespace std;

void contar(int n){
	n--;
	cout<<" "<<n<<endl;
	if(n>0)
		contar(n);
		cout<<" "<<n<<endl;
		
}

int main(int argc, char *argv[]){
	int n;
	
		do
		{
			cout<<"Escriba un numero entero positivo: ";
			cin>>n;
		}while(n<=0);
		
	contar(n);
	
	system("PAUSE");
	return EXIT_SUCCESS;
}
