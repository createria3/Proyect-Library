#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	float z;
	do
	{
		float x,y,z;
		cout<<"\nIngresa tu edad:\t";
		cin>>x;
		
		cout<<"\nEn una escala del uno al diez que tan negro eres:\t";
		cin>>y;
		if(y<=10)
		{
			cout<<"\nContinuemos...";
		}
		if(y>=10)
		{
			cout<<"\nNO MAMES PINCHE NEGRO";
			z++;
		}

	}while(z=1);
	
}
