//Programa que calcula la suma de numeros enteros otorgados por el usuario
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int i=0,x=0,numIn=0,numFin=0;
void pedirDatos();
int suma(int,int);
void imprimir();

int main()
{
	pedirDatos();
	suma(numIn,numFin);
	imprimir();
}

void pedirDatos()
{
	cout<<"Inserte el numero inicial:\t";
	cin>>numIn;
	cout<<"Inserte el numero final:\t";
	cin>>numFin;
	
	if(numIm>numFin)
	{
		cout<<"\nEl valor inicial no puede ser mayor al final";
	}
}

int suma(int numIn, int numFin)
{
	for(i=numIn; i<=numFin; i++)
	{
		x=x+i;
	}
	return x;
}

void imprimir()
{
	cout<<"\nLa suma del num inicial al num final es de:\t"<<x;
	getch();
}
