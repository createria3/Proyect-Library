#include "iostream"
#include "string"
using namespace std;

int main()
{
	struct Persona /*Estas construyendo los valores de la persona*/
	{
		string nombre;
		string apellido;
		int edad;
		string correo;
		string empresa;
		int telefono;
	}; //Aquí al punto y coma, a diferencia de las funciones, aquí hay que ponerlo


	Persona personas[500];/*Num de personas*/
	cout<<"\n\nPor favor ingrese la siguiente informacion de el contacto: \n";
	for(int i = 0; i < 500; i++)
	{
		cout<<"CONTACTO NUMERO"<<i+1<<"\n";
		
		cout<<"\nNombre: ";/*Los que tienen este formato es porque aceptan letras*/
		cin.ignore();
		getline(cin>>ws, personas[i].nombre);
		
		cout<<"\nApellidos: ";
		cin.ignore();
		getline(cin>>ws, personas[i].apellido);
		
		cout<<"\nEdad: ";/*Los que tienen este formato es porque aceptan numeros*/
		cin>>personas[i].edad;
		
		cout<<"\nCorreo: ";
		getline(cin>>ws, personas[i].correo);
		
		cout<<"\nEmpresa: ";
		getline(cin>>ws, personas[i].empresa);
		
		
		cout<<"\nTelefono: ";
		cin>>personas[i].telefono;
	}
	
	return 0;
}