//Programa que sume recursivamente un numero ej.5(1+2+3+4+5)
#include<conio.h>
#include<iostream>
using namespace std;

int num,suma=0;
void pedirDatos();
int contador(int num);
void imprimir();

int main()
{
	pedirDatos();
	contador(num);
	imprimir();
}

void pedirDatos()
{
	cout<<"Ingrese un numero a sumar:\t";
	cin>>num;
}

int contador(int num)
{
	if(num==1)
	{
		suma=1;
	}
	else
	{
		suma=num+contador(num-1);
	}
}

void imprimir()
{
	cout<<"La suma es: "<<suma;
}
