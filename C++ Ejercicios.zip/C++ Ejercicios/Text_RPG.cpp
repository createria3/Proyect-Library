//Juego RPG//
#include<math.h>
#include<stdlib.h>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

//Actual variables//
int i,j,a,b,x,y,z;


//Character elements
int char_eleFIRE=0;
int char_eleWIND=0;
int char_eleEARTH=0;
int char_eleWATER=0;

//Status
int char_stsFIRE=0;
int char_stsWIND=0;
int char_stsEARTH=0;
int char_stsWATER=0;

//Inventory
int inv_space=30;

//Point pool
int pool;
int stat;
int race=0;

//Character values//
int charSTR;
int charHP;
int charAG;
int charDEX;
int charCON;

//Battle
int action=0;
int enemy_action=0;
int enemyHP=10;
int enemySTR=1;
int enemyAG=1;
int enemyDEX=1;
int enemyCON=1;
	
//Levels & EXP
int level;
int EXP;
	
	
void checkEXP()
{
	
}

void combat()
{
	
	
	
	//Fighting system
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n============================================================\n";
	cout<<"Random enemy apeared!";
	cout<<"\n============================================================\n";
	cout<<"Enter any key to continue...\n";
	getch();
	
	do
	{
		cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n============================================================\n";
		cout<<"HP: "<<charHP<<"\t\t\t\tEnemy's HP:  "<<enemyHP<<endl;
		cout<<"What  will you do?!\n  1)Attack\n  2)Defend\n  3)Use Item\n  4)Run\n  5)Charm\n";
		cout<<"============================================================\n";
		cin>>action;
		switch(action)
		{
			case 1:
				enemyHP=enemyHP-((charSTR+1)/enemyCON);
				if(enemyHP==1)
				cout<<"The enemy lost "<<((charSTR+1)/enemyCON)<<" of his total life points!\nThe enemy has "<<enemyHP<<" lifepoint remaining!"<<endl;
				if(enemyHP<=0)
				cout<<"\n============================================================\nRandom enemy was slayed!t You gained: "<<EXP<<"EXP!\n============================================================\n";
				else
				cout<<"The enemy lost "<<((charSTR+1)/enemyCON)<<" of his total life points!\nThe enemy has "<<enemyHP<<" lifepoints remaining!"<<endl;
				break;
			case 2:
				charHP = charHP+1;
				break;
			case 3:
				cout<<"Working on it?...";
				break;
			case 4:
				cout<<"Escaped succesfully!\tNo rewards were given...\nEnter any key to continue...\n";
				getch();
				break;
			case 5:
				/*if(charmLvl>enemy_charmLvl)
				{
					cout<<"\nCharm succesfull!";
				}*/
				cout<<"Charm failed...";
				break;
		}
	}while(enemyHP>0);
}
int main()
{
	system("CLS");
	
	
	
	
	//Choosing race
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n============================================================\nSelect a race:\n  1)Goblin\n  2)Human\n  3)Elf\n============================================================\n";
	cin>>race;
	switch(race)
	{
		//Goblin
		case 1:
			pool = 10;
			char_eleEARTH=1;
			break;
		//Human
		case 2:
			pool = 15;
			char_stsFIRE=1;
			char_stsWIND=1;
			char_stsEARTH=1;
			char_stsWATER=1;
			break;
		//Elf
		case 3:
			pool = 20;
			char_stsWIND=2;
			char_stsEARTH=1;
			char_stsWATER=1;
			break;
	}
	//Designating pool point's//
	for(i=0; i<pool; i++)
	{
		//Despliege de menu//
		cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n============================================================\n\nChoose a stat:\n  1)STRENGHT:  "<<charSTR<<"\n  2)HP:  "<<charHP<<"\n  3)AGILITY:  "<<charAG<<"\n  4)DEXTERITY:  "<<charDEX<<"\n  5)CONSTITUTION:  "<<charCON<<"\nAlocated points:\t"<<pool-i<<"\n============================================================\n";
		cin>>stat;
		switch(stat)
		{
			case 1: 
			charSTR = charSTR+1;
			i=i+1;
			break;
			
			case 2:
			charHP = charHP+1;
			i=i+1;
			break;
			
			case 3:
			charAG = charAG+1;
			i=i+1;
			break;
			
			case 4:
			charDEX = charDEX+1;
			i=i+1;
			break;
			case 5:
			charCON = charCON+1;
			i=i+1;
			break;
		}
		i = i-1;
	}
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nFinal stats:";
	cout<<"\nSTR:  "<<charSTR<<"\nHP:  "<<charHP<<"\nAG:  "<<charAG<<"\nDEX:  "<<charDEX<<"\nCON:  "<<charCON;
	cout<<"\n============================================================\n";
	cout<<"Enter any key to continue...\n";
	getch();
	
	combat();
	
	
	
	
	
}


