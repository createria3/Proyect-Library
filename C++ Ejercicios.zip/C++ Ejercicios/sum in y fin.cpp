//Sumas del profesor con num inicial y final
#include<iostream>
#include<conio.h>
using namespace std;

int sumar(int n);

int main(){
	int numero;
	
	
	do{
		cout<<"Ingrese un numero: ";
		cin>>numero;
	}while(numero<=0);
	
	
	cout<<"La suma es: "<<sumar(numero)<<endl;
	
	getch();
	return 0;
}

int sumar(int n){
	int suma=0;
	
	if(n==1){
		suma = 1;
	}
	else{
		suma = n + sumar(n-1);
	}
	
	return suma;
}
