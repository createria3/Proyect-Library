#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;


int n=5,i=5;
int fact=5;
int factorial();
void mostrarDatos();


int factorial()
{
	n = n* fact;
	fact = fact -1;
}

void mostrarDatos()
{
	cout<<"\nEl factorial de 5 es:"<<n;
}

int main()
{
	do
	{
		factorial();
	}while(i!=0);
	
	
	mostrarDatos();
}
