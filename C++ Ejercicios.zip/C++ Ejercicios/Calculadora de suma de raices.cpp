#include<math.h>//Calculo de numeros positivos o negativos//
#include<stdlib.h>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	//Variables//
	float x,y,z;
	
	//Menu//
	cout<<"A continuacion el programa realizara un calculo de suma de raices cuadradas.\n"<<"Inserta el valor inicial:\t";
	cin>>x;
	cout<<"\nInserta el valor final:\t";
	cin>>y;
	
	if(x>y)
		cout<<"\nEl numero inicial no puede ser mayor al final.";
	//operacion principal//
	for(x=x, y=y; x<=y; x++)
	{
		z=z+sqrt(x);
	}
	cout<<"\n"<<z;
	//Aqui evitas errores del sistema//
	
		
}