/*Programa que reuelve ecuaciones de segundo grado usando funciones de usuario de paso por valor*/
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

float solucion_uno(float a, float b, float c);
float solucion_dos(float a, float b, float c);



int main()
{
	system("cls");
	float x1,x2,a,b,c;
	
	cout<<"Ingresa los valores de a, b y c \n";
	cin>>a>>b>>c;
	
	
	if((pow(b,2)-4*a*c)<0)
	{
		cout<<"Solucion fuera de los numeros reales";
		getch();
		exit(1);
	}
	
	else
	{
		solucion_uno(a,b,c);
		solucion_dos(a,b,c);		
	}
}

float solucion_uno(float a, float b, float c)
{
	float x1;
	
	x1=(-b+sqrt(pow(b,2)-4*a*c))/(2*a);
	cout<<"La primer solucion, X1="<<x1;
	getch();
	
}

float solucion_dos(float a, float b, float c)
{
	float x2;
	
	x2=(-b-sqrt(pow(b,2)-4*a*c))/(2*a);
	cout<<"\nLa segunda solucion, X2="<<x2;
	getch();
}