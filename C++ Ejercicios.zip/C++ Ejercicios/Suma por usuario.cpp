//Programa que sume 2 numeros
#include<cstdlib>
#include<iostream>
using namespace std;

int a,b,c,S;
int suma(int a,int b);

int main()
{
	cout<<"Proporciona 2 valores al programa: \t";
	cin>>a>>b;
	
	S=suma(a, b);
	
	cout<<"\nLa suma de a + b es: "<<S;
}

int suma(int a, int b)
{
	int c;
	c = a + b;
	return c;
}

