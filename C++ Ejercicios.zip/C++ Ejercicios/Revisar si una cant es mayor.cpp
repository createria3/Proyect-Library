//Programa que revise si el valor a superado o igualado a 21
#include<iostream>
using namespace std;

int revisar_cantidad();

int num;
int valorFijo = 21;
bool a = false;

int revisar_cantidad()
{
	cout<<"\nEl valor es: "<<num;
	if(num<valorFijo)
		 cout<<"\nValor no exede 21";
	if(num==valorFijo)
		cout<<"\nValor alcanzado!";
	else
		cout<<"\nValor superado!";
}

int main()
{
	cout<<"Inserte un numero:\t";
	cin>>num;
	
	revisar_cantidad();
	
	system("PAUSE");

}




