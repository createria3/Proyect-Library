#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;


int main()
{
	int x,i;
	system("CLS");
	int num;
	
	cout<<"Ingrese valor deseado\n";
	cin>>num;
	cout<<"===============================================================================\n";
	
	for(x=2, x<num, x++)
	{
		
		for(i=2; i<=x; i=i+1)
		{
			
			if((x%i)==0)
			{
				cout<<"No es primo:\t"<<x;
				cout<<"\n";
			}
		}
		if((x%1)!=0)
		{
			cout<<"Si es primo:\t"<<x;
			cout<<"\n";
		}
	}
}