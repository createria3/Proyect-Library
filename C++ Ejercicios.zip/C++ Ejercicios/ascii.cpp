#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;/*Facilita la escritura de los cout, retirando la necesidad de escribir "std::"*/

void printASCII(char c)
{
	int i = c;
	cout<<"The ACII value of "<<c<<" is "<<i;
}


int main()
{
	printASCII('═¤');
}
	
