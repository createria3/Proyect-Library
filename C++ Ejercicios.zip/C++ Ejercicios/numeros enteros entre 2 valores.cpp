#include<conio.h>
#include<iostream>
using namespace std;

int num_in,num,num_fin,contador,inicio,fin,par,i;
void pedirDatos();
int recursividad(int,int);
void imprimir();

int main()
{
	pedirDatos();
	recursividad(num_in,num_fin);
	imprimir();
}

void pedirDatos()
{
	cout<<"Ingrese 2 valores:\t";
	cin>>num_in>>num_fin;
}

int recursividad(int inicio,int fin)
{
	if(inicio==fin)
	{
		return inicio;
	}
	else
	{
		return recursividad(inicio, fin-1);
	}
}

void imprimir()
{
	for(i=inicio; i<=fin; i++)
	cout<<"\n"<<recursividad(i,fin);
}
