//Matriz simetrica(comprobacion)
#include<iostream>
#include<conio.h>
using namespace std;

void muestra(int matriz[][100],int,int);
void comprobar(int matriz[][100],int,int);
void pedir();

int L,A;
int i,z,contador=0;
int matriz[100][100];


int main()
{
	system("CLS");
	cout<<"Inserte el largo de la matriz:\n";
	cin>>L;
	cout<<"\nIngrese el ancho de la matriz:\n";
	cin>>A;
	
	pedir();
	muestra(matriz,L,A);
	comprobar(matriz,L,A);
	getch();
	return 0;
}

void pedir()
{
	if(L==A)
	{
		for(i=0; i<L; i++)
		{
			for(z=0; z<A; z++)
			{
				cout<<"\nInserte un numero:\t";
				cin>>matriz[i][z];
			}
		}	
	}
	else
	{
		cout<<"\nLa matriz no es simetrica ya que el largo y ancho son desiguales";
		
	}
}

void muestra(int matriz[][100],int L, int A)
{
	cout<<"\n\nVector:\n";
	for(i=0; i<L; i++)
	{
		for(z=0; z<A; z++)
		{
			cout<<"|"<<matriz[i][z]<<"|";
		}
		cout<<"\n";
	}
}

void comprobar(int matriz[][100],int L, int A)
{
	for(i=0; i<L; i++)
	{
		for(z=0; z<A; z++)
		{
			if(matriz[i][z]==matriz[z][i])
			{
				contador = contador+1;
			}
		}
	}
	
	if(contador==(L*A))
	{
		cout<<"La matriz es simetrica!";
	}
	else
	{
		cout<<"La matriz es asimetrica...";
	}
}
