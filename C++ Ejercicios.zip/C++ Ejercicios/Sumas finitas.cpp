#include<math.h>//Calculo de factoriales(x!)//
#include<stdlib.h>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	//Declaracion de  valores//
	system("CLS");
	float x,y,i,j,k,n;
	
	cout<<"Inserte el valor de x: \t";
	cin>>x;

	n=10;
	//Revision de valor de n//
	for(i=1, j=1, k=1; k<n; i=i+2,j++,k++)
	{
		y=y+(pow(x,i)/i)*pow(-1,(j+1));
	}
	cout<<"\n"<<y;
	getch();
}