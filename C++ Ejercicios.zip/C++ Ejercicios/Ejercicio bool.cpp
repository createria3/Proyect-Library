#include<cstdlib>
#include<iostream>
using namespace std;

int main(int argc, char *arvg[])
{
	int x=10, y=12, mayor, menor;
	bool z;
	
	z= x>=y ? true: false;  //z toma el valor de false
	mayor = x>=y ? x: y;	//calcula y almacena el mayor
	menor = x<=y ? x: y;	//calcula y almacena el menor
	
	cout<<"x= "<<x<<"\n";
	cout<<"y= "<<y<<"\n";
	cout<<"el mayor es= "<<mayor<<"\n";
	cout<<"el menor es= "<<menor<<"\n";
	system("PAUSE");
	return EXIT_SUCCESS;
}
