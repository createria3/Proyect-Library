//Programa que identifique las vocales de un nombre
#include<iostream>
#include <cstdlib>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
	system("CLS");
	char *puntero;
	char nombreU[30];
	
	int i=0,x,nombre;
	
	cout<<"Inserte un nombre para identificar sus vocales\n  Las vocales a considerar son:";
	cout<<" a, e, i, o, u";
	cout<<"\nInserte un nombre:\t";
	cin.getline(nombreU,30);
	
	puntero = nombreU;
	
	strupr(nombreU);
	
	//Hacer un bucle para progresar en los char
	do
	{
		switch(puntero[i])
		{
			case 'A':
				cout<<"\nTu nombre contiene una letra A";
				i++;
				break;
					
			case 'E':
				cout<<"\nTu nombre contiene una letra E";
				i++;
				break;
				
			case 'I':
				cout<<"\nTu nombre contiene una letra I";
				i++;
				break;
			
			case 'O':
				cout<<"\nTu nombre contiene una letra O";
				i++;
				break;
			
			case 'U':
				cout<<"\nTu nombre contiene una letra U ";
				i++;
				break;
		}
	}while(i<30);
}
