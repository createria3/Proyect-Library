//Programa que imprime los valores alpha numericos de ASCII
#include <cstdlib>
#include <iostream>
using namespace std;

int main()
{
	char *punteroc;
	char caracter;
	
	punteroc = &caracter;
	cout<<"ASCII caracter"<<endl;
	for(caracter = 'A'; caracter<= 'F'; caracter++)
	cout<<"  "<<(int)caracter<<"     "<<*punteroc<<endl;
	system("PAUSE");
	return EXIT_SUCCESS;
}
