#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;/*Facilita la escritura de los cout, retirando la necesidad de escribir "std::"*/

int x;
int num;


int main()
{
	system("CLS");
	for(x>num;;)
	{
		x++;
		cout<<"NIGGER\t";
	}
}