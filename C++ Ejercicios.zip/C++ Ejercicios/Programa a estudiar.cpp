//Programa que busque el mayor entre 2 numeros
#include<iostream>
using namespace std;

void encontrarMax(int, int);//el prototipo de la funcion

int main()
{
	int primernum, segundonum;
	
	cout<<"Introduzca el primer numero: ";
	cin>>primernum;
	cout<<"\nIntroduzca el segundo numero: ";
	cin>>segundonum;
	
	encontrarMax(primernum, segundonum); //aqui llamamos la funcion
	
	return 0;
}

//en seguida esta la funcion encontrarMax()

void encontrarMax(int x, int y)
{
	int numMax;
	
	if(x>=y)
		numMax=x;
	else
		numMax=y;
	
	cout<<"\nEl maximo de los 2 numeros es "<<numMax<<endl;
	
	return;
}
