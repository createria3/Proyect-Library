#include<iostream>
#include<conio.h>
using namespace std;
void permutar(double &, double &);

int main(void)
{
	double a=1.0, b=2.0;
	
	
	cout<<a<<","<<b<<endl;
	permutar(a, b);
	cout<<a<<","<<b<<endl;
	
	getch();
	return 0;
}

void permutar(double &a, double &b)
{
	double temp;
	
	temp = a;
	a = b;
	b = temp;
}
