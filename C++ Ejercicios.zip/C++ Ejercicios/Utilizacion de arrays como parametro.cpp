//Utilizacion de arrays como parametro

float suma(float a[5]);
float calcula(float a[], int n);
float media(float * a, int n);
//N no es un numero de datos obligtorio, pero es conveniente

int b[5], a[6];

int main()
{
	cout<<suma(a);
	cout<<calcula(b,5);
	cout<<media(b,5);
}
