#include<iostream>
	#include<conio.h>
	using namespace std;
	
	void cubo(int vector[], int);
	void muestra(int vector[], int);
	
	int main(){
		
		const int TAM=5;
		int vector[TAM]={1,2,3,4,5};
		
		cubo(vector,TAM);
		muestra(vector,TAM);
	
		
		getch();
		return 0;
	}
	
void cubo(int vector[], int tam){
	 for(int i=0; i<tam; i++){
	 	
	 	vector[i] = vector[i]*vector[i]*vector[i];   //vector[i] *= vector[i]
	 }	
}

void muestra(int vector[], int tam){
	for(int i=0; i<tam; i++){
		cout<<vector[i]<<" ";
		}
}
