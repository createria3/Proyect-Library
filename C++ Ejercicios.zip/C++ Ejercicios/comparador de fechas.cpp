//Programa que devuelva la fecha mayor entre 2 fechas
//ej.(2012,2010) = 2012 fecha mas reciente
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;


struct fecha
{
	float dia, mes, anyo;
}C1,C2,C3;

int calcular(fecha,fecha,fecha);//Parametros struct
void pedirDato();
void imprimir();

int main()
{
	pedirDato();
	calcular(C1,C2,C3);
	imprimir();
}

void pedirDato()
{
	cout<<"inserte 2 fechas\ndia:";
	cin>>C1.dia;
	cout<<"\nmes:";
	cin>>C1.mes;
	cout<<"\nanyo:";
	cin>>C1.anyo;
	
	cout<<"\ndia:";
	cin>>C2.dia;
	cout<<"\nmes:";
	cin>>C2.mes;
	cout<<"\nanyo:";
	cin>>C2.anyo;
}

int calcular(fecha C1,fecha C2,fecha C3)
{
	if(C1.anyo<C2.anyo)
	{
		C3.anyo=C2.anyo;
		C3.mes=C2.mes;
		C3.dia=C2.dia;
	}
	if(C1.anyo>C2.anyo)
	{
		C3.anyo=C1.anyo;
		C3.mes=C1.mes;
		C3.dia=C1.dia;
	}
	
	
	if(C1.anyo==C2.anyo)
	{
		if(C1.mes<C2.mes)
		{
			C3.anyo=C2.anyo;
			C3.mes=C2.mes;
			C3.dia=C2.dia;
		}
		if(C1.mes>C2.mes)
		{
			C3.anyo=C1.anyo;
			C3.mes=C1.mes;
			C3.dia=C1.dia;
		}
		
		
		if(C1.mes==C2.mes)
		{
			if(C1.dia<C2.dia)
			{
				C3.anyo=C1.anyo;
				C3.mes=C1.mes;
				C3.dia=C1.dia;
			}
			if(C1.dia>C2.dia)
			{
				C3.anyo=C1.anyo;
				C3.mes=C1.mes;
				C3.dia=C1.dia;
			}
		}
	}
	return C3;
}

void imprimir()
{
	cout<<"La fecha mas reciente es: "<<C3.dia<<"/"<<C3.mes<<"/"<<C3.anyo;
}
