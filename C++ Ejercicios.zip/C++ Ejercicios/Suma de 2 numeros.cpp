//Programa que sume 2 numeros complejo haciendo uso de estructura y funciones de ususario
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

struct Complejo
{
	float Real, Imaginario;
}C1,C2;//Estos 2 variables es para saber en que lugar se guarda

void PedirDatos();
Complejo SumarDatos(Complejo,Complejo);
void ImprimirDatos(Complejo);

int main()
{
	PedirDatos();
	Complejo Suma = SumarDatos(C1,C2);
	ImprimirDatos(Suma);
}

void PedirDatos()
{
	cout<<"Ingrese el primer numero complejo: ";
	cout<<"\nParte real: ";
	cin>>C1.Real;
	cout<<"Parte imaginaria: ";
	cin>>C1.Imaginario;
	
	cout<<"\nInserte segundo numero complejo: ";
	cout<<"\nParte real: ";
	cin>>C2.Real;
	cout<<"Parte imaginaria: ";
	cin>>C2.Imaginario;
}
Complejo SumarDatos(Complejo C1, Complejo C2)
{
	C1.Real = C1.Real + C2.Real;
	C1.Imaginario = C2.Imaginario + C1.Imaginario;
	
	return C1;
}
void ImprimirDatos(Complejo Suma)
{
	cout<<"\nEl resultado de la suma de los numeros complejos es: "<<Suma.Real<<" + "<<Suma.Imaginario;
}
