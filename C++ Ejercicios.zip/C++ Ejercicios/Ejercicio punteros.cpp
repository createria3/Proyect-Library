#include<cstdlib>
#include<iostream>
using namespace std;

int main(int argc, char *argv[])
{
	system("CLS");
	int Variable= 75;
	int& Referencia = Variable;
	
	cout<<"Contenido de Variable = "<<Variable<<endl;
	cout<<"Direccion &Variable = "<<&Variable<<endl;
	cout<<"Contenido de Referencia = "<<Referencia<<endl;
	cout<<"Direccion &Referencia = "<<&Referencia<<endl;
	system("PAUSE");
	return EXIT_SUCCESS;
}
