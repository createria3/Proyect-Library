#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;



void pedirDatos();

int contandoVocales(char *nombre);

char nombreUsuario[30];

int main()
{
	pedirDatos();
	cout<<"\nEl numero de vocales contenidas en el nombre es: "<<contandoVocales(nombreUsuario)<<endl;
	
	//numbreUsuario = &nombreUsuario[0]
	getch();
	return 0;
}

void pedirDatos()
{
	 cout<<"Ingrese su nombre: ";
	 cin.getline(nombreUsuario,30,'\n');
	 
	 strupr(nombreUsuario);
}

int contandoVocales(char *nombre)
{
	int contador=0;
	while(*nombre)
	{
		switch(*nombre)
		{
			case 'A':
				case 'E':
					case 'I':
						case 'O':
							case 'U':
								contador++;
		}
		nombre++;
	}
	return contador;
}
