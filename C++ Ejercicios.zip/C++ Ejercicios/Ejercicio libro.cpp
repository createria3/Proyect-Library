#include<iostream>
#include<conio.h>
#include<process.h>
#include<math.h>
#include<stdlib.h>
#include<stdio.h>
struct libro					//nombre de la estructura
{
	char titulo[30];
	char autor[25];
	char editorial[30];
	int anyo;
	float precio;
	char fecha_compra[8];
} l1,l2,l3;						//l1,l2,l2 son variantes de tipo libro

libro l4, l5, l6;				//Son variables tipo libro

int main()
{
	l1= l2 = l3;				//Asignacion de estructuras
	system("PAUSE");
	return EXIT_SUCCESS;
}
