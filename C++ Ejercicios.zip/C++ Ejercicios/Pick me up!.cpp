//Pick me up!  (webtoon)
#include<iostream>
#include<cstdlib>
#include<conio.h>
using namespace std;

int char_sheet();
int LevelUp();

//Estadisticas
int HP;
int DEX;
int STR;
int MANA;
int AGI;
char name[10];
//Niveles
int EXP;
int LV;

/*int Sin Usar (Folder)
{
	//Invocaciones(por estrellas)||permitir anomalias

//Sintetisar (fusion)||usado para obsorber estadisticas

//Base principal


//Crafteo

}
*/

int main()
{
	cout<<"Inserta tu nombre:\t";
	gets(name);
	
	
}

int char_sheet()
{
	cout<<"\n\n\n\n\n\n\n\n\n=================================================================\n";
	cout<<"Player: ";
	puts(name);
	cout<<"\n";
	cout<<"HP: "<<HP<<"DEX: "<<DEX<<"STR: "<<STR<<"MANA: "<<MANA<<"AGI: "<<AGI;
}
int LevelUp()
{
	
}

