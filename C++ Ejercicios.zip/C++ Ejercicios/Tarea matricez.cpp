//En este programa se suman los valores de 2 matrices//
#include<conio.h>
#include<stdio.h>
#include<iostream>
using namespace std;

int main()
{
	system("CLS");
	int matriz1[10][10];
	int matriz2[10][10];
	int matriz3[10][10];
	int i,x,j;
	int h=0;
	int L=0;

	//Preguntar tama�o de matriz//
	cout<<"Inserte la altura de la matriz:\t";
	cin>>h;
	cout<<"\nInserte la longitud de la matriz:\t";
	cin>>L;
	
	
	for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			cout<<"\nIngresa un valor:\t";
			cin>>x;
			matriz1[i][j]=x;
		}
	}
	

	
	cout<<"\n\nInserta la segunda matriz:\t";
	for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			cout<<"\nIngresa un valor:\t";
			cin>>x;
			matriz2[i][j]=x;
		}
	}
	
	//Suma de matricez//
		for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			matriz3[i][j]=matriz1[i][j]+matriz2[i][j];
		}
	}
	
	cout<<"La suma es:\n";
	for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			cout<<"||"<<matriz3[i][j]<<"||";
		}
		cout<<"\n";
	}
}
