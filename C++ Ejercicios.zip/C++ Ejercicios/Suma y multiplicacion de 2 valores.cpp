#include<cstdlib>
#include<iostream>
using namespace std;
/*Programa que retorna 2 valores haciendo uso de funciones de usuario de paso de parametros
por valor y por referencia*/
//Suma y multiplicacion de dos numeros
int num1=0,num2=0, suma=0, producto=0;
void calcular(int,int, int&, int&);

int main()
{
	cout<<"Ingrese 2 numeros: ";
	cin>>num1>>num2;
	calcular(num1,num2, suma, producto);
	
}
void calcular(int num1,int num2,int & suma,int & producto)
{
	suma = num1 + num2;
	producto = num1 * num2;
	
	cout<<"\nLa suma es: "<<suma;
	cout<<"\nEl producto es: "<<producto;
}
