#include<process.h>
#include<conio.h>
#include<math.h>
#include<iostream>

int main()
{
	float x,y;
	
	system("CLS");
	
	std::cout<<"Ingresa X=";
	std::cin>>x;
	
	if(x<-3)
	{
		if(x==4)
		{
			std::cout<<"indeterminacion";
			getch();
			exit(0);
		}
		else()
		{
			y=(pow(x,3)+1)/(x+4);
		}
	}
	
	else
	{
		if(x>=-3 && x<=3)
		{
			if(x==2)
			{
				std::cout<<"Indeterminación";
				getch();
				exit(1);
			}
			
			else
			{
				y=exp(x)/(x-2);
			}
		}
	}
	
	else
	{
		if(x==5)
		{
			cout<<"Indeterminación"
			getch();
			exit();
		}
		
		else
		{
			y=sin(x)/(x-5);
		}
	}
	
	cout<<"y="<<y;
	getch();
	
	
}

