#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
using namespace std;

float funcion1(float);
float funcion2(float);

int main()
{
	
	system("cls");
	float x,y;
	
	cout<<"ingresa X="<<endl;
	cin>>x;
	
	if(x<2)
	{
		
		y=funcion1(x);
		cout<<"Si el valor de x es menor a 2, y="<<y<<endl;
		getch();
		exit(0);	
	}
	else
	{
		y=funcion2(x);
		cout<<"Si el valor de X fue mayor o igual a 2, y="<<y<<endl;
		getch();
	}
}

float funcion1(float x)
{
	float y;
	y=(3*pow(x,2)-2*x+1);
	return y;
}

float funcion2(float x)
{
	float y;
	y=(pow(sin(x),2)-1);
	return y;
}