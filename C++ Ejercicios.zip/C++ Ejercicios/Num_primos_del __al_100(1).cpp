#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;/*Facilita la escritura de los cout, retirando la necesidad de escribir "std::"*/

int main()
{
	/*Variables*/
	int num;
	int x,y;
	int end1;
	
	
	/*Menu*/
	cout<<" =============================================================\n";
	cout<<" Ingresa el numero maximo a calcular que se encuentre dentro de\n los numeros reales y no supere 100 unidades\n";
	cout<<" =============================================================\n\n";
	cin>>num;/*Solicitando los valores*/

	if(num<=100)
	{
		
		
		/*Calcular si X es menor que el numero dado*/
		for(x>num;;)
		{
			x++;
			if(x<num+1)
			{
				if((num%x)==0)
				{
					cout<<x;
					cout<<"\nNo es primo\t";
					cout<<"\n";
				}
			}
			
			else
			{
				break;
			}
			
		}
	}
	
	else
	{
		cout<<"El numero es mayor que 100\n";
		cout<<"Reinicia el programa e introduce una cantidad menor a 100\n\n";
	}
}