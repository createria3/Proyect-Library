#include<conio.h>
#include<iostream>
using namespace std;


int a[100];
int tamanyo,i;
int val=80032738;
int *puntero;

int main()
{
	cout<<"Inserte el tama�o del arreglo:\t";
	cin>>tamanyo;
	
	cout<<"\nIngrese "<<tamanyo<<" valores:\t";
	for(i=0; i<tamanyo; i++)
		cin>>a[i];
	
	
	puntero=a;
	//Calculo	
	for(i=0; i<tamanyo; i++)
	{
		if(*puntero<val)
			val = *puntero;
		
		puntero++;
	}
	
	cout<<"El numero mas peque�o del arreglo es "<<val;
	getch();
	return 0;
}
