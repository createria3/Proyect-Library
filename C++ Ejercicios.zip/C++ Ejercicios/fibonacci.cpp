//Programa que ingrese cuantos elementos quiere de la serie de fibonacci
#include<conio.h>
#include<iostream>
using namespace std;

void pedirDatos();
int fibonacci(int n);
void imprimir();

int n,i, suma, valor;

int main()
{
	pedirDatos();
	fibonacci(valor);
	imprimir();
	getch();
	return 0;
}

void pedirDatos()
{
	cout<<"Ingrese la cantidad de elementos que quiere calcular con la serie de fibonacci:\t";
	cin>>valor;
}

int fibonacci(int n)
{
	if(n<2)
	{
		return n;
	}
	else
	{
		return fibonacci(n-1)+fibonacci(n-2);
	}
}

void imprimir()
{
	for(i=0; i<valor; i++)
	{
		cout<<"\nEl valor es de: "<<fibonacci(i);
	}
}
