/*realizar un programa que despliegue un menu para ejecutar la funcion matematica deseada*/
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	
	/*Limpieza de pantalla*/
	system("CLS");
	
	/*Valores y funciones*/
	float x,y,e;
	int ecuacion;
	
	/*Declaras el valor de X*/
	std::cout<<"Ingresa el valor de X=\n";
	std::cin>>x;
	
	/*Imprimes las opciones*/
	std::cout<<"\n=======================================================================================";/*Su funcion es astetica*/
	std::cout<<"\nseleciona una de las opciones\n -caso 1\n -caso 2\n -caso 3\n";
	switch(ecuacion)/*aqui escribes una variable para tomar de base*/
	{
		
		/*Declaras la cant. de casos*/
		case 1:
			std::cout<<"\n=======================================================================================";/*Su funcion es astetica*/
			y=(pow(x,3)*2)-x-1;/*Ecuacion*/
			std::cout<<"\nEl valor de X es ="<<y;
			break;/*Declaras que el programa termino*/
	
		case 2:
			e==2.71828;
			std::cout<<"\n=======================================================================================";/*Su funcion es astetica*/
			y=pow(e,-x)-pow(e,x);/*Ecuacion*/
			std::cout<<"\nEl valor de X es ="<<y;
			break;/*Declaras que el programa termino*/
		
		case 3:
			e==2.71828;
			std::cout<<"\n=======================================================================================";/*Su funcion es astetica*/
			y=(2*(x-1))/(pow(x,3)-2*x+8);/*Ecuacion*/
			std::cout<<"\nEl valor de X es ="<<y;
			break;/*Declaras que el programa termino*/
	}
}