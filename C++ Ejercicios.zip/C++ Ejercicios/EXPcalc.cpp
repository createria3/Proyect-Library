//D&D EXP calculator
#include<math.h>
#include<stdlib.h>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

void XPcheck();
void CHARsheet();

int HP=10;
int STR=1;
int lvl=1,xp=0,LVLxp=50,extraXP=20;
int XPgain;
int options;

int i,x,z;

int main()
{
	for(z=0; z<100; z++)
	{
		CHARsheet();
		XPcheck();		
		CHARsheet();
		
		cin>>XPgain;
		xp = xp+XPgain;
	}
}


void XPcheck()
{
	if(xp>=LVLxp)
	{
		cout<<"\nLvl up?\n1)yes\n2)no\n";
		cin>>options;
		
		switch(options)
		{
			case 1:
				cout<<"Leveled up!";
				lvl=lvl+1;
				LVLxp = LVLxp + extraXP;
				if(i=10)
				{
					i=0;
					extraXP = extraXP * 2;
				}
				else
				{
					extraXP = extraXP + 10;
				}

				i++;
				break;
			case 2:
				cout<<"\nWHY???";
				break;
		}
	}
}

void CHARsheet()
{
	cout<<"\n=================================================\n";
	cout<<"\nHP-->"<<HP;
	cout<<"\nSTR->"<<STR;
	cout<<"\nLVL->"<<lvl;
	cout<<"\n=================================================\n\n\n\n";
}
