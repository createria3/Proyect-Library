//Programa que eleve un numero a un exponente ej. 6^3=216
#include<conio.h>
#include<iostream>
using namespace std;

int valor, num=0, potencia=0, exponente, total;

void pedirDatos();
int elevar(int potencia, int);
void imprimir();

int main()
{
	pedirDatos();
	elevar(num, exponente);
	imprimir();
}

void pedirDatos()
{
	cout<<"Ingrese un valor:\t";
	cin>>num;
	
	cout<<"\nIngrese la potencia:\t";
	cin>>exponente;
}

int elevar(int num, int potencia)
{
	if(potencia==1)
	{
		total = num;
	}
	else
	{
		total=num * elevar(num, potencia-1);
	}
	return total;
}

void imprimir()
{
	cout<<"\n"<<num<<" elevado a la "<<exponente<<" es igual a: "<<total;
}
