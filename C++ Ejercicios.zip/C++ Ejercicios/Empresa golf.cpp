#include <stdio.h>
#include <stdlib.h>
#include<iostream>
using namespace std;

int main()
{
	int i;
	cout<<"Que nota quieres revisar\n 1)Que va a ser el negocio?\n 2)Que va a vender?\n 3)A quien se vende?\n 4)Como se va a vender?\n 5)Nombre y logo\n 6)Que falta en la bolsa de golf?";
	cout<<"\n 7)Que coleccionan los jugadores de golf\n 8)Gorras\n";
	cin>>i;
	cout<<"\n";
	switch(i)
	{
		case 1:
			cout<<"============================================================";
			cout<<"\n  -Venta de ropa y accesorios de golf";
			cout<<"\n============================================================";
			break;
		case 2:
			cout<<"============================================================";
			cout<<"\n  -Ropa\n  -artilugios\n  -accesorios\n  -sombreros\n  -organizador\n  -guarda pelotas";
			cout<<"\n============================================================";
			break;
		case 3:
			cout<<"============================================================";
			cout<<"\n  -Golfistas en general";
			cout<<"\n============================================================";
			break;
		case 4:
			cout<<"============================================================";
			cout<<"\n  -Marketplace\n  -Tienda digital\n  -Mercado libre,ebay,amazon\n  -En el circulo de golfistas\n  -Red de direcctores de campos de golf";
			cout<<"\n============================================================";
			break;
		case 5:
			cout<<"============================================================";
			cout<<"\n  -Logo: Albatroz\n  -Nombre: Loazo";
			cout<<"\n============================================================";
			break;
		case 6:
			cout<<"============================================================";
			cout<<"\n  -Organizadoor tipo piel(BONITO)\n  -Headcovers(fierros,putters,maderas)\n  -Palos para recuperar pelotas\n  -Paraguas\n  -Sostenedor de putter\n  -Guardador de bolas";
			cout<<"\n============================================================";
			break;
		case 7:
			cout<<"============================================================";
			cout<<"\n  -Pelotas de golf\n  -Marcas(BALL MARKER)";
			cout<<"\n============================================================";
			break;
		case 8:
			cout<<"============================================================";
			cout<<"\n  -Future scratch golfer\n  -Birdie,eagle,albatroz,a dream\n  -Rock n' roll(IMAGEN DE PIEDRA Y BOLA DE GOLF RODANDO)\n  -Agila golfista\n  -Nido de pajaros con pelotas\n  -Pro golf frases";
			cout<<"\n============================================================";
			break;
	}
}
