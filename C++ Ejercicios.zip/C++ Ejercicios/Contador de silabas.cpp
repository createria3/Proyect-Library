#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

void pedirDatos();
int buscar(char *);
void imprimir();

int i=0,*puntero,x=0;
char nombre[50];

int main()
{
	pedirDatos();
	buscar(nombre);
	imprimir();
	
	getch();
	return 0;
}

void pedirDatos()
{
	cout<<"Ingrese ingrese un nombre:\t";
	cin.getline(nombre,50);
	
	
	strupr(nombre);
}

int buscar(char * nombre)
{
	int cont = 0;
		
	while(*nombre)
	{                                         
		switch(*nombre)
		{
			case 'A': 
			case 'E':
			case 'I':
			case 'O':
			case 'U': 
			
			cont++;
		}
		nombre++;
	}
			
	return cont;
}


void imprimir()
{
	cout<<"La cantidad de vocales en el nombre ingresado es de:\t"<<buscar(nombre);
}
