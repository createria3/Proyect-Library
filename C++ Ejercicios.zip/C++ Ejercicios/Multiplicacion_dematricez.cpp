//En este programa se multiplican los valores de 2 matrices//
#include<conio.h>
#include<stdio.h>
#include<iostream>
using namespace std;

int main()
{
	system("CLS");
	int matriz1[3][3];
	int matriz2[3][1];
	int matriz3[10][10];
	int matriz4[10][10];
	int matriz5[10][10];
	int matriz6[10][10];
	int i,x,j;
	int h=0;
	int L=0;

	//Preguntar tama�o de matriz//
	cout<<"Inserte la altura de la matriz:\t";
	cin>>h;
	cout<<"\nInserte la longitud de la matriz:\t";
	cin>>L;
	
	
	for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			cout<<"\nIngresa un valor:\t";
			cin>>x;
			matriz1[i][j]=x;
		}
	}
	

	
	cout<<"\n\nInserta la segunda matriz:\t";
	for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			cout<<"\nIngresa un valor:\t";
			cin>>x;
			matriz2[i][j]=x;
		}
	}
	
	//multiplicacion de matrices//
	for(i=0; i<3; i++)
	{
		if(j==0)
		matriz3[i][j] = matriz1[i][j] * matriz2[i][j];
	}
	
	
	cout<<"La multiplicacion es:\n";
	for(i=0; i<h; i++)
	{
		for(j=0; j<L; j++)
		{
			cout<<"||"<<matriz3[i][j]<<"||";
		}
		cout<<"\n";
	}
}
