#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;/*Facilita la escritura de los cout, retirando la necesidad de escribir "std::"*/


int main()
{
	/*Variables*/
	int num;
	int x;
	system("CLS");
	x=0; /*Declaramos que X es igua a cero para que empieze a calcular desde alli*/
	
		
	/*Menu*/
	cout<<" +=============================================================+\n";
	cout<<" Ingresa el numero maximo a calcular que se encuentre dentro de\n los numeros reales\n";
	cout<<" +=============================================================+\n\n";
	cin>>num;/*Solicitando los valores*/
	
	cout<<"Su numero es menor o igual a 100";
	/*Calcular si X es menor que el numero dado*/
	for(x<=num;;)
	{
		if(x<=num+1)
		{
			if((num%x)==0)/*Calcular si el numero tiene residuo, en caso de tener, es primo*/
			{
				cout<<"\n\n";
				cout<<x;
				cout<<" No es primo";
				cout<<"\n";
			}
		}
		else
		{
			cout<<"Algo salio mal...";
		}
	}
}