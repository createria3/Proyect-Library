#include<math.h>//Calculo de factoriales(x!)//
#include<stdlib.h>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	system("CLS");
	float x ,y, factorial;
	
	cout<<"Inserte el numero a calcular:\n";
	cin>>x;
	
	factorial=1;
	
	for(y=1; y<=x; y++)
	{
		factorial=y*factorial;
	}
	
	cout<<"El factorial es: "<<factorial<<"\n";
	

}