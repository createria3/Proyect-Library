#include<conio.h>
#include<iostream>
using namespace std;

int a[10];
int *puntero;
int i;

int main()
{
	cout<<"Ingrese 10 valores:\n";
	for(i=0; i<10; i++)
	{
		cin>>a[i];
	}
	
	puntero=a;
	
	for(i=0; i<10; i++)
	{
		if(a[i]==0)
		{
			
		}
		else
		{
			if(a[i]%2==0)
			{
				*puntero=a[i];
				cout<<"\nElemento par: "<<a[i];
				cout<<"\nUbicacion de memoria: "<<puntero;
			}
			puntero++;
		}
	}
}
