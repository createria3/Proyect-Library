//Declarar un arreglo de numeros enteros de tama�o 40 e inicializar cada uno de sus elementos en 0//

#include<iostream>
#include<conio.h>

using namespace std;
void print0(int, int&);

int A[40];
int i;

int main()
{
	print0(A);
	
	
}

void print0(int i, int & chain)
{
	for(i=0; 1<40; i++)
		A[i]=0;
		
	for(i=0; 1<40; i++)
		cout<<A[i]<<"\n";
		getch();
}
