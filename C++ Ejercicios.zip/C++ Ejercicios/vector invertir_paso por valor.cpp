//Programa que ingrese valores y invierta su valor (positivos a negativos, negativos a positivos)
#include<iostream>
#include<conio.h>
using namespace std;

void pedir();
void invertir(int vector[], int);
void imprimir(int vector[], int);

int vector[100];
int TAM,i;

int main()
{
	pedir();
	
	invertir(vector,TAM);
	
	imprimir(vector,TAM);
	getch();
	return 0;
}

void pedir()
{
	cout<<"Ingrese el tama�o del vector: ";
	cin>>TAM;
	
	for(i=0; i<TAM; i++)
	{
		cout<<"\nIngrese un valor:\t";
		cin>>vector[i];
	}
}

void invertir(int vector[],int TAM)
{
	for(i=0; i<TAM; i++)
	{
		vector[i] = vector[i] * -1;
	}
}

void imprimir(int vector[], int TAM)
{
	for(i=0; i<TAM; i++)
	{
		cout<<"\nValor "<<i<<":\t"<<vector[i];
	}
}
