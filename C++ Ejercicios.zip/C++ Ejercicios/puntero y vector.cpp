#include<conio.h>
#include<iostream>
using namespace std;

int tamanyo,i,menor=0;
int *puntero;
int a[1000];



int main()
{
	cout<<"Cuantos elementos desea ingresar: ";
	cin>>tamanyo;
	cout<<"\nIngrese "<<tamanyo<<" valor(es)";
	
	
	
	for(i=0; i<tamanyo; i++)
		cin>>a[i];
	
	puntero=a;
	
	for(i=0; i<tamanyo; i++)
	{
		if(*puntero<menor)
		{
			menor=*puntero;
		}
		puntero++;
	}
	
	cout<<"\n"<<menor;
	getch();
	return 0;
	
}
