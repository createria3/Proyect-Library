#include<iostream>
#include<conio.h>
using namespace std;

void pedirDatos();
int ordenar(int [],int);
void imprimir();

int *valor,i,j,temp,CantNum;

//Inicio de programa
int main()
{
	pedirDatos();
	ordenar(valor, CantNum);
	imprimir();
}

void pedirDatos()
{
	cout<<"Ingrese la cantidad de numeros:\t";
	cin>>CantNum;
	
	valor= new int [CantNum];
	
	for(i=0; i<CantNum; i++)
	{
		cout<<"\nIngrese un valor:\t";
		cin>>valor[i];
	}
}
/*
int ordenar(int valor[], int CantNum)
{
	for(i=0; i<CantNum - 1; i++)
	{
		for(j=i+1; j<CantNum; j++)
		{
			if(valor[i] > valor[j])
			{
				temp = valor[i];
				valor[i] = valor[j];
				valor[j] = temp;
			}
		}
	}
}*/

int ordenar(int valor[], int CantNum)
{
	for(i=0; i<CantNum; i++)
	{
		for(j=0; j<CantNum-1; j++)
		{
			if(valor[j] > valor[j+1])
			{
				temp = valor[j];
				valor[j] = valor[j+1];
				valor[j+1] = temp;
			}
		}
	}
}
void imprimir()
{
	cout<<"\nLos valores ordenados son:";
	for(i=0; i<CantNum; i++)
		cout<<valor[i]<<endl;
}
