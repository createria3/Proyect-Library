#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	int x,i;
	i=0;
	system("CLS");
	int numero_especificado;
	
	std::cout<<"Inserte un numero entero\n"<<numero_especificado;
	
	
	
	while(i<numero_especificado)
	{
		cout<<1;
		
		for(i=1; 1<numero_especificado; i=1+1)
	{
		
		if((numero_especificado%i)==0)
		{
			cout<<"No es primo";
			getch();
			exit(0);
		}
	}
	}
	
	
	cout<<"Si es primo";
	getch();
	
	
	
}