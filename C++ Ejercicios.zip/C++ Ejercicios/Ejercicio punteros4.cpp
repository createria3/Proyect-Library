//Programa que determina si un valor es par o impar con punteros
#include<math.h>
#include<stdlib.h>
#include<cstdlib>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	system("CLS");
	
	int var;
	int *pun;
	
	pun = &var;
	//Solicitando valores
	cout<<"Ingresa un valor para saber si es par o impar:\t";
	cin>>*pun;	
	
	cout<<"\n"<<*pun<<endl;
	
	if(*pun % 2 == 0)
	{
		cout<<"Es par..."<<endl;
		cout<<"Contenido de Variable = "<<var<<endl;
		cout<<"Direccion &Variable = "<<&pun<<endl;
		cout<<"Contenido de Referencia = "<<var<<endl;
		cout<<"Direccion &Referencia = "<<&pun<<endl;
		system("PAUSE");
		return EXIT_SUCCESS;
	}
	
	if(*pun % 2 != 0)
	{
		cout<<"Es impar..."<<endl;
		cout<<"Contenido de Variable = "<<var<<endl;
		cout<<"Direccion &Variable = "<<&pun<<endl;
		cout<<"Contenido de Referencia = "<<var<<endl;
		cout<<"Direccion &Referencia = "<<&pun<<endl;
		system("PAUSE");
		return EXIT_SUCCESS;
	}
}
