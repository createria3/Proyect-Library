//asignacion dinamica de arreglos
#include<iostream>
#include<conio.h>
using namespace std;

void PedirCalificaciones();
void mostrarNotas();
int NumCal,*calificacion;

int main()
{
	
	PedirCalificaciones();
	mostrarNotas();
	
	getch();
	return 0;
}

void PedirCalificaciones()
{
	cout<<"Ingrese el numero de calificaciones: ";
	cin>>NumCal;
	
	calificacion=new int[NumCal];
	
	
	for(int i=0; i<NumCal; i++)
	{
		cout<<"\nIngrese las notas de las calificaciones: ";
		cin>>calificacion[i];
	}
}

void mostrarNotas()
{
	cout<<"Las notas son: ";
	for(int i=0; i<NumCal; i++)
	{
		cout<<calificacion[i]<<endl;
	}
}
