#include <cstdlib>
#include<iostream>
#include<string.h>
using namespace std;

int main()
{
	char *Cadena = "Montes de Toledo en Castilla la Mancha";
	int  * pEntero, lonCadena, Entero=15;
	char *pCadena;
	
	lonCadena = strlen(Cadena);
	pCadena = new char[lonCadena+1];	//Memoria con una posici�n fin cadena
	strcpy(pCadena, Cadena);			//Copia cadena a nueva �rea de memoria
	pEntero = new int;					//se reserva memoria para un entero
	*pEntero = Entero;					//se almacena en contenido de pEntero 15
	cout<<"pCadena= "<<pCadena<<"longitud= "<<lonCadena<<endl;
	delete pCadena;						//libera memoria de pCadena
	cout<<"*pEntero= "<<*pEntero<<endl;
	delete pEntero;						//libera memoria de pEntero
	system("PUASE");
	return EXIT_SUCCESS;
	
}
