//Programa que use recursividad para sumar un numero ej.4 (1+2+3+4)
#include<conio.h>
#include<iostream>
using namespace std;

int recursividad(int);
void pedirDatos();
void imprimir();


int n, valor, suma;

int main()
{
	//Pedir datos
	pedirDatos();
	
	//Recursividad
	recursividad(valor);
	
	//Imprimir
	imprimir();
}

void pedirDatos()
{
	cout<<"Ingrese un valor a sumar de manera recursiva:\t";
	cin>>valor;
}

int recursividad(int n)
{
	if(n==1)
	{
		suma = 1;
	}
	else
	{
		suma=n+recursividad(n-1);
	}
	return suma;
}

void imprimir()
{
	cout<<"\nLa suma recursiva es de: "<<recursividad(valor);
}

