//Programa que almacena "n" numeros en un arreglo dinamico y posteriormente busque un numero de los insertados
#include<iostream>
#include<conio.h>
using namespace std;

void pedirDatos();
int buscarDatos();
void imprimir();

int *valor,i,x,CantDatos,*puntero;

int main(){
	
	pedirDatos();
	buscarDatos();
	imprimir();
	
	getch();
	return 0;
}

void pedirDatos(){
	cout<<"Ingrese la cantidad de datos a ingresar:\t";
	cin>>CantDatos;
	
	valor = new int [CantDatos];
	
	for(i=0; i<CantDatos; i++)
	{
		cout<<"\nIngrese un valor:\t";
		cin>>valor[i];
	}
}

int buscarDatos(){
	//Queremos que el usuario le de un valor a "x" y con ese dato usando un for() progresemos el arreglo dinamico hasta igualar el numero y guardarlo ej.(5 5!=4, 5=5; cout<<el "x" es el "n" numero en la lista
	cout<<"\nIngrese un valor a buscar:\t";
	cin>>x;
	
	
	*puntero = valor[i];
	
	for(i=0; i<CantDatos; i++)
	{
		cout<<"\nRonda: "<<i;
		
		if(x==valor[i])
		{
			cout<<"\nEl valor fue encontrado!";
		}
		else
		{
			cout<<"\nValor no encontrado...";
		}
	}
}

void imprimir(){
	
}
