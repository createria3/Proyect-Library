//Programa que invierta una cadena de numeros
#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

void invertir(/*Faltan parametros*/);
void mostrar();

//Declaracion de elementos globales
int cadena[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int *puntero;
int *q, *p;
int i,x;
int cadenaINV[10];


void invertir()
{
	//Guarda los datos de atraz para adelante usando cadenaINV y despues guarda sus ubicaciones con el puntero
	int i,x;
	do
	{
		*q=cadena[x];
		cadenaINV[i]=cadena[x];
		i++;
		x--;
	}while(i<10);
	
	cout<<"Vector invertido:\t";
	for(i=0; i<10; i++)
	{
		cout<<cadenaINV[i];
		cout<<"\n"<<*q;
	}
}



int main()
{
	
	int i;
	
	invertir();
	
	
	
	
}

