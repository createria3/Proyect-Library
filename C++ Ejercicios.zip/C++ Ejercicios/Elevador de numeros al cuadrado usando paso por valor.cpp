/*Paso de parametros de tipo vector
Pparametros de la funcion: void nombreDeFuncion(Tipo nombreArreglo[],int tama�oArreglo)

LLamada a la funci�n
 nombreDeFuncion(nombreArreglo, tama�oArreglo)*/

#include<iostream>
#include<cstdlib>
#include<conio.h>
using namespace std;

int i;
int num[10];
int Vector[10];


void elevar(int Vector[],int);
void imprimir(int Vector[],int);

int main()
{
	const int TAM=10;
		int vector[TAM];
	cout<<"Inserte 10 valores a elevar al cuadrado:\n";
	for(i=0; i<10; i++)
		cin>>Vector[i];
	
	elevar(Vector, 10);
	imprimir(Vector, 10);
	
	for(i=0; i<10; i++)
		cout<<Vector[i];
	getch();
	return 0;
}

void elevar(int Vector[], int num[])
{
	for(int i=0; i<10; i++)
	{
		Vector[i] = Vector[i]*Vector[i];   //vector[i] *= vector[i]
	}	
}

void imprimir()
{
	for(i=0; i<10; i++)
	{
		cout<<Vector[i]<<" ";
	}
}
