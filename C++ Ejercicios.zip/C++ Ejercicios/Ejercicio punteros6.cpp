//Programa que sume 2 valores a base de punteros y arreglos
#include <cstdlib>
#include <iostream>
using namespace std;

int main()
{
	system("CLS");
	float *puntero;
	float valor[10];
	int i,x;
	
	cout<<"\nInserte 2 valores 10 veces para obtener una sumatoria";
	cout<<"\nInserta 2 valores a sumar:\n";
	
	
	for(i=0; i<10; i++)
	{
		puntero = &valor[i];
		//Solicitando valores
		cout<<"Ingresa un valor:\t";
		cin>>*puntero;	
	}
	cout<<"\n";
	for(i=0; i<10; i++)
	x=x+valor[i];
	
	for(i=0; i<10; i++)
	{
		cout<<"\nUbicacion del valor num "<<i<<": "<<&valor[i];
	}
	*puntero = x;
	cout<<"\n\n\n\n=============================================================|";
	cout<<"\n\tLa suma de los valores es:\t"<<x;
	cout<<"\n\tLa direccion de los valores es:"<<&x;
	cout<<"\n=============================================================|";
	cout<<"Proceso terminado, presione cualquier tecla para finalizar...";
	system("PAUSE");
	return EXIT_SUCCESS;
	
}
