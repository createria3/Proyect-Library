#include<cstdlib>
#include<iostream>
using namespace std;

int main()
{
	system("CLS");
	int var;
	int *pun;
	
	pun = &var;
	*pun = 60;
	cout<<"&var. Direccion de var = "<<&var<<endl;
	cout<<"pun. Contenido de pun es la misma direccion de var ";
	cout<<pun<<endl;
	cout<<"var. Contenido de var = "<<var<<endl;
	cout<<"*pun. El contenido *pun es el mismo que el de var: ";
	cout<<*pun<<endl;
	system("PAUSE");
	return EXIT_SUCCESS;
}
