//Programa que sume 2 valores a base de punteros y arreglos
#include <cstdlib>
#include <iostream>
#include<conio.h>
using namespace std;
int i=0,x=0, y=0;
float suma;
float valor[10];

int solicitar_valor();



int main(float, int &)
{
	int i=0,x=0, y=0;
	system("CLS");
	
	
	
	cout<<"\nInserte 2 valores 10 veces para obtener una sumatoria";
	cout<<"\nInserta 2 valores a sumar:\n";
	
	solicitar_valor(suma,valor[]);
	
	
	
	for(i=0; i<10; i++)
	{
		cout<<valor[x];
	}
	getch();
	return 0;
}

int solicitar_valor(float suma, valor)
{
	int i=0,x=0, y=0;
	for(x=0; x<10; x++)
	{
		for(i=0; i<2; i++)
		{
			cout<<"Ingresa un valor:\t";
			cin>>suma;
			y = suma + suma++;
			
		}
		cout<<"\n"<<y;
		valor[x] = suma;
	}
}
