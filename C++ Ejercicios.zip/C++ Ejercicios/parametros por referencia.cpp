	//Programa que pasa parametros por referencia
#include<iostream>
#include<conio.h>

using namespace std;

void ValorNuevo(int&, int&);

int main(){
	
	int Numero1, Numero2;
	
	cout<<"Ingrese 2 Numeros: "<<endl;
	cin>>Numero1>>Numero2;
	
	ValorNuevo(Numero1, Numero2);
	
	cout<<"El nuevo valor del primer numero es: "<<Numero1<<endl;
	cout<<"El nuevo valor del primer numero es: "<<Numero2<<enl;
	
	
	getch();
	return 0;
}

void ValorNuevo(int& xnumero, int& ynumero){
	
	cout<<"El valor del primero numero es: "<<xnumero<<endl;
	cout<<"El valor del primero numero es: "<<ynumero<<endl;
	xnumero=23;
	ynumero=9;
	
}
