#include<math.h>//Calculo de numeros positivos o negativos//
#include<stdlib.h>
#include<process.h>
#include<conio.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	float x;
	
	cout<<"Da un valor a calcular:\t";
	cin>>x;
	
	if(x>0)
		cout<<"El numero es positivo.";
	
	if(x<0)
		cout<<"El numero es negativo.";
	
	if(x==0)
		cout<<"X no tiene valor";
}