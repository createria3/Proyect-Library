#include<process.h>
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	//Queremos hacer un programa que detecte los numeros pares del 1 al 100//
	int numero,par,x,i,contador=0;
	cout<<"Los numeros pares son:\n";
	
	for(numero=2; numero<=100; numero++)
	{
			if(numero%2==0)
				cout<<"\n"<<numero;
				contador=0;
			
			if(numero%2!=0)
				contador=contador+1;
	}
}