#include<conio.h>
#include<stdio.h>
#include<iostream>
using namespace std;

int main()
{
	int m,n,f,c,i,j,k;
	float matriz[100][100],matriz2[100][100],matriz3[100][100];
	cout<<"\n==================================================\n";
	cout<<"\nINGRESE LA FILA Y COLUMNA DE LA PRIMERA MATRIZ\n";
	cin>>m;
	cin>>n;
	cout<<"\n==================================================\n";
	cout<<"\nINGRESE LA FILA Y COLUMNA DE LA SEGUNDA MATRIZ\n";
	cin>>f;
	cin>>c;
	cout<<"\n";
	if(n==f)
	{
		cout<<"\n==================================================\n";
		cout<<"INGRESE EL VALOR DE LA PRIMERA MATRIZ\n\n";
		//INGRESE LAS MATRICES
		for(i=1;i<=m;i++)
		{
			for (j=1;j<=n;j++)
			{
				cout<<"A"<<i<<j<<"= ";
				cin>>matriz[i][j];
			}
		}
		cout<<"\n";
		cout<<"\n==================================================\n";
		cout<<"\nINGRESE EL VALOR DE LA SEGUNDA MATRIZ\n\n";
		for (i=1;i<=f;i++)
		{
			for (j=1;j<=c;j++)
	    	{
				cout<<"B"<<i<<j<<"= ";
				cin>>matriz2[i][j];
    		}
			//OPERACION DE MULTIPLICACION
			for (i=1;i<=m;i++)
    		{
				for (j=1;j<=c;j++)
				{
					matriz3[i][j]=0;
    				for (k=1;k<=n;k++)
    				{
						matriz3[i][j]=matriz3[i][j]+matriz[i][k]*matriz2[k][j];
					}
				}
			}
			cout<<"\n==================================================\n";
			cout<<"\nLA MULTIPLICACION DE LAS MATRICES ES:\n\n";
			//IMPRESION
			for(i=1;i<=m;i++)
			{
				for(j=1;j<=c;j++)
				{
					/*cout<<"C"<<i<<j<<"=\t"<<f<<"\n"<<matriz3[i][j];	%4.2f\n",matriz3[i][j];*/
					//printf("C(%d,%d)=\t%4.2f\n",i,j,C[i][j]);
					printf("C(%d,%d)=\t%4.2f\n",i,j,matriz3[i][j]);
				}
			}
		}
		getchar(); getchar();
	}
}
