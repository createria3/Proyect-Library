#include<iostream>
#include<conio.h>
using namespace std;

void pedir();
int sumar(int vector[], int);
void imprimir();

int total=0;
int vector[100];
int TAM,i;




int main()
{
	pedir();
	
	sumar(vector,TAM);
	
	imprimir();	
}


//Pedir tama�o de vector y los elementos del vector
void pedir()
{
	cout<<"Ingrese el tama�o del vector: ";
	cin>>TAM;
	
	for(i=0; i<TAM; i++)
	{
		cout<<"\nIngrese un valor:\t";
		cin>>vector[i];
	}
}

int sumar(int vector[], int TAM)
{
	for(i=0; i<TAM; i++)
	{
		total = total + vector[i];
	}
	return total;
}

void imprimir()
{
	cout<<"\nEl total es: "<<total;
}
