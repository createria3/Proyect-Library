//funcion de usuario de paso por referencia
//EScribir un programa que intercambie el valor de 2 variable utilisando paso de parametros por referencia
#include<iostream>
#include<conio.h>

using namespace std;

void intercambiar(int&, int&);

int Numero1, Numero2;

int main()
{
	
	
	cout<<"Ingrese 2 Numeros: "<<endl;
	cin>>Numero1>>Numero2;
	
	cout<<"Los valores que ingresaste son: "<<Numero1<<Numero2;
	
	intercambiar(Numero1,Numero2);
	
	cout<<"\nEl primer valor invertido es: "<<Numero1<<endl;
	cout<<"El segundo valor invertido es: "<<Numero2<<endl;
	
}

void intercambiar(int &Numero1, int &Numero2)
{
	int aux;
	aux = Numero1;
	Numero1=Numero2;
	Numero2 = aux;
	
	
}
