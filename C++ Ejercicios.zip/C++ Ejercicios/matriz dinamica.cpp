#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;

void pedirDatos();
void mostrarMatriz(int **,int,int);

int **puntero_matriz,nFilas,nColumnas;

int main()
{
	pedirDatos();
	mostrarMatriz(puntero_matriz,nFilas,nColumnas);
	
	//Para liberar la memoria que hemos utilizado en la matriz
	for(int i=0; i<nFilas; i++)
	{
		delete[] puntero_matriz[i];
	}
	delete[] puntero_matriz;
	
	getch();
	return 0;
}

void pedirDatos(){
	cout<<"Digite el numero de filas: ";
	cin>>nFilas;
	cout<<"Digite el numero de columnas: ";
	cin>>nColumnas;
	
	//Reservar memoria para la primera matriz
	puntero_matriz = new int*[nFilas];				//Reservar memoria para las filas
	
	for(int i=0; i<nFilas;i++)
	{
		puntero_matriz[i]=new int[nColumnas];
	}
	
	cout<<"\nDigitando los elementos de la matriz: \n";
	for(int i=0;i<nFilas;i++)
	{
		for(int j=0;j<nColumnas;j++)
		{
			cout<<"Digite un numero["<<i<<"]["<<j<<"]: ";
			cin>>*(*(puntero_matriz+i)+j);
		}
	}
}

void mostrarMatriz(int **puntero_matriz, int nfilas, int nColumnas)
{
	cout<<"\n\nImprimiendo Matriz:\n";
	for(int i=0;i<nFilas;i++)
	{
		for(int j=0;j<nColumnas;j++)
		{
			cout<<*(*(puntero_matriz+i)+j);	//puntero_matriz[i][j]
		}
		cout<<"\n";
	}
}
