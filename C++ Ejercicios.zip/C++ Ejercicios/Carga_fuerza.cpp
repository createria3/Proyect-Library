#include<stdio.h>
#include<math.h>
#include<conio.h>

main()
{
	
	float q1,q2,r,F,k;
	k=9*pow(10,9);
	
	printf("Ingrese la carga q1\n");
	scanf("%f",&q1);
	
	printf("Ingrese la carga q2\n");
	scanf("%f",&q2);
	
	printf("Ingrese la carga r\n");
	scanf("%f",&r);
	
	F=k*q1*q2/pow(r,2);
	
	printf("La fuerza es:%f", F);
	
}