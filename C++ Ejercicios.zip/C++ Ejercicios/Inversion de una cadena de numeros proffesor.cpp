#include <iostream>

using namespace std;

void Mostrar(int*, int);
void Intercambia(int*, int*);

int main() {
    
	
	int vector[10] = { 2,5,6,7,9,12,35,67,88,99 };
    int *p, *q;

    Mostrar(vector, 10);                        // Mostrar estado inicial

    p = vector;                                // Primer elemento
    q = &vector[9];                             // Ultimo elemento

    while(p < q) {                               // Bucle de intercambio
        Intercambia(p++, q--);
    }
    Mostrar(vector, 10);                        // Mostrar estado final
    return 0;
}

void Mostrar(int *v, int n) {
    int *f = &v[n];                             // Puntero a posici�n siguiente al �ltimo elemento
    while(v < f) {
        cout << *v << " ";
        v++;
    }
    cout << endl;
}

void Intercambia(int *p, int *q) {
                                         // Intercambiar sin usar variables auxiliares:
    *p += *q;
    *q = *p-*q;
    *p -= *q;
}
