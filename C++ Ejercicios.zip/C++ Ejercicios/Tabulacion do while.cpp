#include<conio.h>
#include<iostream>
#include<math.h>
#include<ctype.h>
using namespace std;

float funcion_fx(float x)
{
	float y;
	y= (2*pow(x,3)-x-1)/x;
	return y;
}

int main()
{
	
	float x,y,LI,LS,I;
	char(opcion);
	
	do
	{
		system("CLS");
	
	
		do
		{
			cout<<"Dame el limite inferior de la tabulacion: ";
			cin>>LI;
			cout<<"Dame el limite inferior :";
			cin>>LS;
			cout<<"Dame el incremento: ";
			cin>>I;
			
		}while(LI>=LS || I<=0);
		
		x=LI;
		
		do
		{
		if(x==0)
		{
			cout<<"Indeterminacion\n";
		}
		else
		{
			y=funcion_fx(x);
			cout<<"La tabulacion es: "<<y<<"\n";
		}
		
			x=x+I;
		}while(x<=LS);
		do
		{
			cout<<"Quieres volver a tabular?";
			cout<<" S)i o N)o";
			
			opcion=getche();
			
			opcion=toupper(opcion);
		}while(opcion!='S' && opcion!='N');
		
		}while(opcion=='S');
		
		
		
}