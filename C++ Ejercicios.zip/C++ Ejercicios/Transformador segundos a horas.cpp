//Transformador segundos -> horas,minutos,segundos
#include<iostream>
#include<cstdlib>
using namespace std;

void tiempo(int,int&,int&,int&);
int totalsec;
int h,minuto,sec;
int x;

int main()
{
	cout<<"Da un valor en segundos para convertirlo en horas minutos y segundos respectivamente:	";
	cin>>totalsec;
	tiempo(totalsec,h,minuto,sec);
	
	cout<<"\nHoras: "<<h<<"\nMinutos: "<<minuto<<"\nSegundos: "<<sec;
}

void tiempo(int totalsec, int &h, int &minuto, int &sec)
{
	/*do
	{
		h = h+1;
		totalsec = totalsec-360;
		
		
		if(totalsec<360)
		{
			totalsec = totalsec+360;
			do
			{
				minuto = minuto+1;
				totalsec = totalsec-60;
			}while(totalsec>60);
		}
		
	}while(totalsec>360);*/
	
	h = totalsec/3600;
	totalsec = totalsec%3600;
	
	minuto = totalsec/60;
	totalsec = totalsec%60;
	
	sec = totalsec;
}
