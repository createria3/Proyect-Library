#include<conio.h>
#include<iostream>
using namespace std;

int factorial(int);
void PedirDatos();
void MostrarResultado();

int numero;

int main()
{
	PedirDatos();
	int factorial(numero);
	MostrarResultado();
	
	getch();
	return 0;
}

void PedirDatos()
{
	cout<<"Ingrese el numero al cual quiere calcular su factorial:	"<<endl;
	cin>>numero;
}

int factorial(int n)
{
	if(n==0)
	{
		n=1;					//caso base
	}
	else
	{
		n=n*factorial(n-1);		//caso general
	}	
	return n;
}

void MostrarResultado()
{
	cout<<"El resultado es: "<<factorial(numero);
}
