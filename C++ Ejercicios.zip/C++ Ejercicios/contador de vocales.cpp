#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

void pedirDatos();
int contador(char * vocales);
void imprimir();

int a=0,e=0,i=0,o=0,u=0,j,x,*puntero;
char vocales[100];

int main()
{
	pedirDatos();
	contador(vocales);
	imprimir();
	
	getch();
	return 0;
}

void pedirDatos()
{
	cout<<"Ingrese sus vocales:\n";
	cin.getline(vocales,100);
	
	strupr(vocales);
}

int contador(char * vocales)
{
	int cont = 0;
		
	while(*vocales)
	{                                         
		switch(*vocales)
		{
			case 'A':	a++; break;
			case 'E':	e++; break;
			case 'I':	i++; break;
			case 'O':	o++; break;
			case 'U':	u++; break;
		}
		vocales++;
	}
			
	return a;
	return e;
	return i;
	return o;
	return u;
}

void imprimir()
{
	cout<<"\nLa cantidad de vocales son:\na:"<<a<<"\ne:"<<e<<"\ni:"<<i<<"\no:"<<o<<"\nu:"<<u;
}
