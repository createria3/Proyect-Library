#include<process.h>
#include<process.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
	int numero,primo,x,contador=0;
	system("cls");
	
        
        cout<<"Hasta que numero primo quieres calcular?\n";
        cin>>primo;
        cout<<"\n";
        
		cout<<"Los numeros primos son:\n";
		for(numero=2; numero<=primo; numero++)
		{
		
			for(x=2; x<=primo; x++)
				if(numero%x==0)
					contador=contador+1;
					
					if(contador==1)
					cout<<"\n"<<numero;
					contador=0;
        }
			getch();	
}