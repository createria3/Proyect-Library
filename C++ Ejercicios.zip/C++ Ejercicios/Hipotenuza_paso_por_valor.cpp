/*funciones de usuario de paso por valor*/

#include<stdio.h>
#include<math.h>

void hipo(float x, float y);

int main()
{
	float a,b;
	
	printf("\n Da los valores de los catetos");
	scanf("%f%f", &a,&b);
	
	hipo(a,b);
	
	printf("\n catetos A=%f B=%f", a,b);
}

void hipo(float x,float y)
{
	float h;
	
	h=sqrt((pow(x,2))+pow(y,2));
	
	printf("\n hipotenuza=%f",h);
}