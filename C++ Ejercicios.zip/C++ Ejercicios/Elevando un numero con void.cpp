//Programa que eleve un numero a una potencia usando void
#include<cstdlib>
#include<iostream>
#include<math.h>
using namespace std;

void solicitar();
void resultado(int valor, int potencia);
int potencia, valor;

int main()
{
	solicitar();
	
	resultado(valor, potencia);
}


void solicitar()
{
	cout<<"Ingrese un valor:\t";
	cin>>valor;
	cout<<"Ingrese una potencia:\t";
	cin>>potencia;
	cout<<valor<<"\n"<<potencia;
}


void resultado(int base, int exponente)
{
	double r;
	r = pow(valor, potencia);
	cout<<"\nEl resultado es: "<<r;
}

